package data;

import java.sql.SQLException;


public class Test {

	public static void main(String[] args) throws SQLException {
		// TODO Auto-generated method stub
ConnessioneDB.connect();
   
	}

}
